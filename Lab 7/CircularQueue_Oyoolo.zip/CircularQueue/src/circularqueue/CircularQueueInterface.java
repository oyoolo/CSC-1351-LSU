/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package circularqueue;

/**
 *
 * @author aoyool1
 */
public interface CircularQueueInterface<E>
{
    public int size();
    public boolean isEmpty();
    public void enqueue(E data);
    public E front() throws Exception;
    public E dequeue() throws Exception;
}