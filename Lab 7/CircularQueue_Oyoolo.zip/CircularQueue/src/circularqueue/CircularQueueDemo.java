package circularqueue;

public class CircularQueueDemo
{
    public static void main(String []args)
    {
        try
        {
            CircularQueue<Character> chars = new CircularQueue();
            chars.enqueue('S');
            System.out.printf("S inserted in the queue.\n");
            chars.enqueue('T');
            System.out.printf("T inserted in the queue.\n");
            chars.enqueue('R');
            System.out.printf("R inserted in the queue.\n");
            chars.enqueue('E');
            System.out.printf("E inserted in the queue.\n");
            chars.enqueue('S');
            System.out.printf("S inserted in the queue.\n");        
            chars.enqueue('S');
            System.out.printf("S inserted in the queue.\n");
            chars.enqueue('E');
            System.out.printf("E inserted in the queue.\n");        
            chars.enqueue('D');
            System.out.printf("D inserted in the queue.\n");
            System.out.println();
            
            System.out.println("Queue = " + chars);
            System.out.println();
            
            if (!chars.isEmpty())
                System.out.println("The queue is not empty.");
            else
                System.out.println("The queue is empty.");
            System.out.println();
            
            chars.rotateCounterclockwise();
            System.out.println("After rotating counterclockwise, queue = " 
                    + chars);
            chars.rotateClockwise();
            System.out.println("After rotating clockwise, queue = " 
                    + chars);
            System.out.println();
            
            while (!chars.isEmpty())
            {
                System.out.printf("%c is at the front of the queue.\n",
                        chars.front());
                System.out.printf("%c has been removed from the queue.\n",
                        chars.dequeue());
                System.out.println("Queue = " + chars);
                System.out.println();
            }
            
            if (!chars.isEmpty())
                System.out.println("The queue is not empty.");
            else
                System.out.println("The queue is empty.");
            System.out.println();
                        
            System.out.println("Calling nums.front()");
            System.out.printf("%c is at the front of the queue.\n",
                    chars.front());
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
}
