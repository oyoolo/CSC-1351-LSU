package sorttimer2;

import java.util.Scanner;
import java.util.Random;
import java.util.Arrays;

/**
 * @author Aubrey Oyoolo Creates an array of random integers. Uses the selection
 * sort, insertion sort, merge sort and quick sort to sort the array. Gets and
 * prints run times for the sort methods.
 */
public class SortTimer2 {

    /**
     * Uses the selection sort to sort an array of integers into increasing
     * order.
     *
     * @param nums the array to be sorted
     */
    public static void selectionSort(int[] nums) {

        // One by one move boundary of unsorted subarray 
        for (int i = 0; i < nums.length - 1; i++) {
            // Find the minimum element in unsorted array 
            int minIndex = i;
            for (int j = i + 1; j < nums.length; j++) {
                if (nums[j] < nums[minIndex]) {
                    minIndex = j;
                }
            }

            // Swap the found minimum element with the first 
            // element 
            int temp = nums[minIndex];
            nums[minIndex] = nums[i];
            nums[i] = temp;
        }
    }

    public static void selectionSortPrint(int[] nums) {
        selectionSort(nums);
        System.out.println("nums =  " + Arrays.toString(nums));
    }

    /**
     * Uses the insertion sort to sort an array of integers into increasing
     * order.
     *
     * @param nums the array to be sorted
     */
    public static void insertionSort(int[] nums) {
        {

            for (int i = 1; i < nums.length; ++i) {
                int key = nums[i];
                int j = i - 1;

                /* Move elements of arr[0..i-1], that are 
               greater than key, to one position ahead 
               of their current position */
                while (j >= 0 && nums[j] > key) {
                    nums[j + 1] = nums[j];
                    j--;
                }
                nums[j + 1] = key;
            }
        }
    }

    public static void insertionSortPrint(int[] nums) {
        insertionSort(nums);
        System.out.println("nums =  " + Arrays.toString(nums));
    }

    // Uses the merge sort to sort the subarray nums[left..right].
    public static void mergeSort(int[] nums, int left, int right) {
        int mid;
        if (left < right) {
            mid = (left + right) / 2;
            if (left < mid) {
                
                mergeSort(nums, left, mid);
            }
            if (mid + 1 < right) {
                
                mergeSort(nums, mid + 1, right);
            }
            ////
            int[] result = new int[right - left + 1];
            int m = left, n = mid + 1, k = 0;

            while (m <= mid && n <= right) {
                if (nums[m] <= nums[n]) {
                    result[k] = nums[m];
                    k++;
                    m++;
                } else {
                    result[k] = nums[n];
                    k++;
                    n++;
                }
                
            }    
                if (n > mid + 1) {

                    if (m <= mid) {
                        for (int i = m; i <= mid; i++) {
                            result[k] = nums[i];
                            k++;
                        }

                    } else {
                        for (int i = n; i <= right; i++) {
                        result[k] = nums[i];
                        k++;
                    }
                }
                for (int j = 0; j <= right - left; j++) {
                    nums[left + j] = result[j];
                }

            }
        }

    }

    // Uses the merge sort to sort the subarray nums[left..right].
    // Prints the nums array after the subarray nums[left..right] has been
    // sorted.
    public static void mergeSortPrint(int[] nums, int left, int right) {
        mergeSort(nums, left, right);
        System.out.println("nums =  " + Arrays.toString(nums));
    }

    // Uses the quick sort to sort the subarray nums[left..right].
    public static void quickSort(int[] nums, int left, int right) {
        if (left < right) {
            /* p is partitioning index, num[p] is now
           at right place */
            int p = partition(nums, left, right);
            // Before pi
            if (left < p){
             quickSort(nums, left, p);   
            } 
            // After pi
            if (p+1 < right){
             quickSort(nums, p+1, right);   
            }  
            
        }
    }

    // Partitions the subarray nums[left..right].
    public static int partition(int[] nums, int left, int right) {
        int pivot = nums[left];
        int i = left - 1;
        int j = right + 1;
        while (i < j) {
//            while(nums[i] < pivot){
//                i++;
//            }
//
//            while (nums[j] < pivot) {
//                j--;
//            }
            i++;
            j--;
            if (i < j) {
                int temp = nums[j];
                nums[j] = nums[i];
                nums[i] = temp;
            }
        }
        return j;
    }

    // Uses the quick sort to sort the subarray nums[left..right].
    // Prints the nums array after the subarray nums[left..right] has been
    // partitioned.    
    public static void quickSortPrint(int[] nums, int left, int right) {
        quickSort(nums, left, right);
        System.out.println("nums =  " + Arrays.toString(nums));
    }

    public static void main(String[] args) {

        int[] numsSelection = {5, 6, 4, 7, 2, 1, 8, 3};
        System.out.println("Selection Sort:");
        System.out.println("nums = " + Arrays.toString(numsSelection));
        selectionSortPrint(numsSelection);
        System.out.println();

        int[] numsInsertion = {5, 8, 4, 6, 2, 1, 7, 3};
        System.out.println("Insertion Sort:");
        System.out.println("nums = " + Arrays.toString(numsInsertion));
        insertionSortPrint(numsInsertion);
        System.out.println();

        int[] numsMerge = {5,3,6,4,2,0,1};
        System.out.println("Merge Sort:");
        System.out.println("nums = " + Arrays.toString(numsMerge));
        mergeSortPrint(numsMerge, 0, numsMerge.length-1);
        System.out.println();

        int[] numsQuick = {5, 8, 4, 7, 2, 1, 6, 3};
        System.out.println("Quick Sort:");
        System.out.println("nums = " + Arrays.toString(numsQuick));
        quickSortPrint(numsQuick, 0, numsQuick.length - 1);
        System.out.println();

        int seed = 0;
        Random rand = new Random(seed);
        int maxRandomValue = 1000000;
        int numRuns = 3;
        Scanner in = new Scanner(System.in);
        System.out.println("Enter the starting value for the length n of "
                + "the array to be sorted, the stepsize by which n is "
                + "increased, and the number of steps: ");
        int start = in.nextInt();
        int stepSize = in.nextInt();
        int numSteps = in.nextInt();
        int end = start + numSteps * stepSize;
        System.out.println();

        for (int n = start; n <= end; n += stepSize) {
            int[] nums1 = new int[n];
            int[] nums2 = new int[n];
            int[] nums3 = new int[n];
            int[] nums4 = new int[n];
            long sum1 = 0;
            long sum2 = 0;
            long sum3 = 0;
            long sum4 = 0;
            int m;

            for (int j = 1; j <= numRuns; j++) {
                for (int i = 0; i < n; i++) {
                    m = rand.nextInt(maxRandomValue) + 1;
                    nums1[i] = m;
                    nums2[i] = m;
                    nums3[i] = m;
                    nums4[i] = m;
                }

                long startTime = System.currentTimeMillis();
                selectionSort(nums1);
                long endTime = System.currentTimeMillis();
                long elapsedTime = endTime - startTime;
                sum1 += elapsedTime;

                startTime = System.currentTimeMillis();
                insertionSort(nums2);
                endTime = System.currentTimeMillis();
                elapsedTime = endTime - startTime;
                sum2 += elapsedTime;

                startTime = System.currentTimeMillis();
                mergeSort(nums3, 0, nums3.length - 1);
                endTime = System.currentTimeMillis();
                elapsedTime = endTime - startTime;
                sum3 += elapsedTime;

                startTime = System.currentTimeMillis();
                quickSort(nums4, 0, nums4.length - 1);
                endTime = System.currentTimeMillis();
                elapsedTime = endTime - startTime;
                sum4 += elapsedTime;
            }
            long average1 = (long) (1. * sum1 / numRuns);
            long average2 = (long) (1. * sum2 / numRuns);
            long average3 = (long) (1. * sum3 / numRuns);
            long average4 = (long) (1. * sum4 / numRuns);
            System.out.printf("n = %6d   Sort Run Time (milliseconds):  "
                    + "Selection: %4d   Insertion: %4d   Merge: %3d"
                    + "   Quick: %3d\n",
                    n, average1, average2, average3, average4);
        }

    }

}
