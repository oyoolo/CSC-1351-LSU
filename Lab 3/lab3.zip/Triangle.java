
package triangledemo;
import java.awt.geom.Point2D;
import static triangledemo.Polygon.distance;

/**
 *
 * @author Oyoolo
 */
public class Triangle extends Polygon {
    /**
    *
    * Constructor
    * @param vertices -arrays x-y coordinates
    */
    public Triangle(Point2D.Double[] vertices){
        super(vertices);
    }
    
    /**
     *
     * @return area of triangle
     */
    @Override
    public double area(){
        double s = this.perimeter()/2;  
        double a = Math.sqrt(s*(s-distance(vertices[0],vertices[1]))*
                            (s-distance(vertices[1],vertices[2]))*
                            (s-distance(vertices[0],vertices[2])));
        return a;
        
    }
    
    /**
     *
     * @return the formatted string output
     */
    @Override
    public String toString(){
        return String.format("{(%.1f,%.1f),(%.1f,%.1f),(%.1f,%.1f)}", 
                vertices[0].x, vertices[0].y, vertices[1].x, vertices[1].y, 
                vertices[2].x, vertices[2].y);
    }
    
    
}
