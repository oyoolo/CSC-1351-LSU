
package triangledemo;

import java.awt.geom.Point2D;

public abstract class Polygon {
    //Array of x,y coordinates
    Point2D.Double[] vertices;
    
    //Constructor
    public Polygon(){
        
    }
    /**
     *
     *@param vertices  creates polygon
     */ 
    
    public Polygon(Point2D.Double[] vertices){
        this.vertices = vertices;
    }
    /**
     *
     * @param p1 first point
     * @param  p2 second point
     */
    protected static double distance(Point2D.Double p1, Point2D.Double p2){
        return Math.sqrt(Math.pow((p1.x-p2.x),2)+Math.pow((p1.y-p2.y),2));
    }
    
    /**
     *
     * @return area when implemented
     */
    public abstract double area();
     /**
     *
     * @return perimeter of polygon
     */
    public double perimeter(){
        double total = 0;
        
        for(int i = 0; i < vertices.length-1; i++){
            total += distance(vertices[i],vertices[i+1]);
        }
        total += distance(vertices[0],vertices[vertices.length-1]);
        return total;
    }
    /**
     *
     * @return getter for object
     */
    public Point2D.Double[] getVertices(){
        return this.vertices;
    }
     /**
     *
     * setter for object
     * @param pts -the array of x,y coordinates
     */
    public void setVertices(Point2D.Double[] pts){
        this.vertices = pts;
    }
    
}
