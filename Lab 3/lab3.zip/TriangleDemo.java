
package triangledemo;
import java.awt.geom.Point2D;
/**
 * Creates a triangle object 
 * @author Oyoolo Aubrey
 */
public class TriangleDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //new Triangle objects
        Triangle first = new Triangle(new Point2D.Double[]{new Point2D.Double(9,9), new Point2D.Double(11, 14), new Point2D.Double(13, 17)});
        Triangle second = new Triangle(new Point2D.Double[]{new Point2D.Double(5,6), new Point2D.Double(5, 46), new Point2D.Double(14, 6)});
        
        //Print out calculations
        System.out.printf("The coordinates of the first triangle are: " + first.toString() + "\n");
        System.out.printf("The perimeter of the first triangle is: %.4f \n", first.perimeter());
        System.out.printf("The area of the first triangle is: %.4f \n", first.area());
        System.out.printf("\n");
        
        System.out.printf("The coordinates of the second triangle are: " + second.toString()+ "\n");
        System.out.printf("The perimeter of the second triangle is: %.4f \n", second.perimeter());
        System.out.printf("The area of the second triangle is: %.4f \n",  second.area());
    }
    
}
