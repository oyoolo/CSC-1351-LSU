package list;

public interface ListIteratorInterface<E> {

    /**
     * Returns true if there is a node on the right of the iterator; otherwise,
     * returns false.
     */
    public boolean hasNext();

    /**
     * Returns true if there is a node on the left of the iterator; otherwise,
     * returns false.
     */
    public boolean hasPrevious();

    /**
     * Resets the iterator's previousPosition to its current position, resets
     * the iterator's current position to the node on the right of its current
     * position (moves the iterator, in the forward direction, past the node on
     * the right), and returns the data value in the node that the iterator just
     * passed over. Throws an exception if the iterator is at the end of the
     * list.
     */
    public E next() throws Exception;

    /**
     * Resets the iterator's previousPosition to its current position, resets
     * the iterator's current position to the node on the left of its current
     * position (moves the iterator, in the backward direction, past the node on
     * the left), and returns the data value in the node that the iterator just
     * passed over. Throws an exception if the iterator is at the beginning of
     * the list.
     */
    public E previous() throws Exception;

    /**
     * Inserts a new node on the left of the iterator and resets the iterator
     * position to this inserted node.
     */
    public void add(E data);

    /**
     * Removes the last node passed over by the iterator in a call to either
     * next or previous. Throws an exception if remove is not called immediately
     * after a call to either next or previous.
     */
    public void remove() throws Exception;

    /**
     * Replaces the data value in the node on the left of the iterator with the
     * input data value. Throws an exception if the node on the left of the
     * iterator is null.
     */
    public void set(E data) throws Exception;

}
