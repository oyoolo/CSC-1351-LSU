/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package list;

/**
 *
 * @author ochia
 * @param <E>
 */
public interface ListIteratorInterface<E> {

    /**
     * Return true if there is a node on the right of the iterator otherwise
     * return false.
     *
     * @return
     */
    public boolean hasNext();

    /**
     * Resets the iterators previousPositin to current
     *
     * @return @throws Exception
     */
    public E next() throws Exception;

    /**
     * Inserts a new node on the left of the iterator and resets the iterator
     * position to this inserted node
     *
     * @param data
     */
    public void add(E data);

    /**
     * Replace the data value in the node on the left of the iterator with the
     * input data value Throw exception of the node on the left of iterator is
     * null
     *
     * @param data
     * @throws Exception
     */
    public void set(E data) throws Exception;

}
