package list;

/**
 *
 * @author ochia
 */
public class List<E> {

    private Node first;
    private Node last;
    private int length;

    private class Node {

        public E data;
        public Node next;
        public Node prev;
    }

    public List() {
        first = null;
        last = null;
        length = 0;
    }

    public int size() {
        return length;

    }

    //Add node to the beginning of the list
    public void addFirst(E data) {
        Node newNode = new Node();
        newNode.data = data;
        if (length == 0) {
            first = newNode;
            last = newNode;
        } else {
            newNode.next = first;
            first.prev = newNode;
            first = newNode;
        }
        length++;

    }

    //add data to the end of the list
    public void addLast(E data) {
        Node newNode = new Node();
        newNode.data = data;
        if (length == 0) {
            first = newNode;
            last = newNode;
        } else {
            newNode.prev = last;
            last.next = newNode;
            last = newNode;
        }
        length++;

    }

    //Remove first element from list
    public E removeFirst() throws Exception {

        if (length == 0) {
            throw new Exception("Non-Empty Stack is Expected");
        }
        E data = first.data;

        if (length == 1) {
            first = null;
            last = null;
        } else {
            first = first.next;
            first.prev = null;
        }
        length--;
        return data;
    }

    public E removeLast() throws Exception {

        if (length == 0) {
            throw new Exception("Non-Empty Stack is Expected");
        }
        E data = last.data;

        if (length == 1) {
            first = null;
            last = null;
        } else {
            last = last.prev;
            last.next = null;
        }
        length--;
        return data;
    }

    public E getFirst() throws Exception {
        if (length == 0) {
            throw new Exception("Non-Empty Stack is Expected");
        }
        return first.data;
    }

    @Override
    public String toString() {
        String string = "[";
        if (length > 0) {
            Node node = first;
            string = node.data + string;

            while (node != last) {
                node = node.next;
                string = node.data + ", " + string;
            }
        }

        string += "]";
        return string;
    }

    public class ListIterator implements ListIteratorInterface<E> {

        private Node position;
        private Node previousPosition;
        private boolean isAfterNext;
        private boolean isAfterPrevious;

        public ListIterator() {
            position = null;
            previousPosition = null;
            isAfterNext = false;
            isAfterPrevious = false;
        }

        public ListIterator listIterator() {
            return new ListIterator();
        }

        /**
         * Return true if there is a node on the right of the iterator otherwise
         * return false.
         *
         * @return
         */
        @Override
        public boolean hasNext() {
            if (position == null) {
                return first != null;
            } else {
                return position.next != null;
            }
        }

        /**
         * Resets the iterators previousPosition to current
         *
         * @return @throws Exception
         */
        public E next() throws Exception {
            if (length == 0) {
                throw new Exception("Non-Empty Stack is Expected");
            }
            previousPosition = position;
            if (position == null) {
                position = first;
            } else {
                position = position.next;
            }
            isAfterNext = true;
            return position.data;
        }

        /**
         * Inserts a new node on the left of the iterator and resets the
         * iterator position to this inserted node
         *
         * @param data
         */
        public void add(E data) {

        }

        /**
         * Replace the data value in the node on the left of the iterator with
         * the input data value Throw exception of the node on the left of
         * iterator is null
         *
         * @param data
         * @throws Exception
         */
        public void set(E data) throws Exception {
            if (length == 0) {
                throw new Exception("Non-Empty Stack is Expected");
            }
        }

    }

}
