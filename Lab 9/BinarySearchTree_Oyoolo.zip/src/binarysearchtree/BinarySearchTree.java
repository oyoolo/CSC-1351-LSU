package binarysearchtree;

/**
 * @author Your name (first and last)
 */

public class BinarySearchTree<E extends Comparable> 
        implements BinarySearchTreeInterface<E>
{
    private Node root; 
    private int size;
    private boolean firstNodePrinted;
    
    private class Node 
    {
        public E data; 
        public Node left; 
        public Node right;
    } 
    
    public BinarySearchTree() 
    { 
        root = null; 
        size = 0; 
        firstNodePrinted = false;
    } 
    
    public int size() 
    { 
        return size; 
    }
    
    public boolean isEmpty() 
    { 
        return size == 0; 
    }
    
    public void insertItem(E data) 
    { 
        Node newNode = new Node(); 
        newNode.data = data; 
        if (size == 0) 
        { 
            root = newNode; 
            size++; 
        } 
        else 
        { 
            Node node = root; 
            while (true) 
            { 
                int d = data.compareTo(node.data); 
                if (d==0) 
                    return; 
                else if (d<0) 
                { 
                    if (node.left == null) 
                    {  
                        node.left = newNode; 
                        size++; 
                        return; 
                    } 
                    else 
                        node = node.left; 
                } 
                else 
                { 
                    if (node.right == null) 
                    {
                        node.right = newNode; 
                        size++; 
                        return; 
                    } 
                    else 
                        node = node.right; 
                } 
            } 
        } 
    }
    
    private Node search(E key) 
    { 
        Node node = root; 
        while (node != null) 
        { 
            int d = key.compareTo(node.data); 
            if (d == 0) 
                return node; 
            else if (d < 0) 
                node = node.left; 
            else 
                node = node.right; 
        } 
        return null; 
    }

    public boolean inTree(E item) 
    { 
        return search(item) != null; 
    }
       
    private Node findParent(Node inputNode) 
    { 
    	
    	//This is the new root/parent
        Node root = this.root; 
        if (inputNode == root) 
            return null; 
        while(true) 
        { 
            int d = inputNode.data.compareTo(root.data);
            if (d < 0) 
            { 
                if (inputNode == root.left) 
                    return root; 
                root = root.left; 
            } 
            else 
            {
                if (inputNode == root.right) 
                    return root; 
                root = root.right; 
            } 
        } 
    }
    
	@Override
	public void removeItem(E data)
    {
        Node node = search(data);
        if (node != null)
        {
            remove(node);
            size--;
        }
    }
    
    private void remove(Node inputNode)
    {
        Node parent, focusNode, replacementNode;
        E replacementData;
        parent = findParent(inputNode);
        
        
        if (inputNode.left != null)
        {
        	//If node to be deleted (parent) has left  and right children
            if (inputNode.right != null)
            {
                focusNode = inputNode.right;
                
                //focus on the lower-most left child node on the bottom-right of the tree
                while (focusNode.left != null) {
                    focusNode = focusNode.left;
                }
                
                //Temporarily store the lower-most left Node's data before removal
                replacementData = focusNode.data;
                remove(focusNode);
            
                //replace the data to be deleted with the data from the lower-most left child node
                inputNode.data = replacementData;
                return;
            }
            else
            	
            	//If node to be deleted (parent) has only left child, thats the one to be replace
                replacementNode = inputNode.left;
        }
        else
        	
        	//If node to be deleted (parent)  only has right child/no child
        	
        {	
        	//If node to be deleted (parent) has right child, this is the one to be replaced
            if (inputNode.right != null)
                replacementNode = inputNode.right;
            else
            	
            	//If node to be deleted (parent) has no children
                replacementNode = null;
        }
        
        //If node to be deleted (parent) has no parent its the root of the tree
        if (parent==null)
            root = replacementNode;
        //If it has a parent
        else if (parent.left == inputNode)
            parent.left = replacementNode;
        else
            parent.right = replacementNode;
    }

    

    public void printTreeInOrder() 
    {
        firstNodePrinted = true;
        System.out.print("root = " + root.data + ",   tree = [");
        printInOrder(root);
        System.out.println("]");
        System.out.println();
    }

    private void printInOrder(Node node) 
    { 
        if (node != null) 
        { 
            printInOrder(node.left);
            if(firstNodePrinted)
            {
                System.out.print(node.data);
                firstNodePrinted = false;
            }
            else
                System.out.print(", " + node.data);
            printInOrder(node.right); 
        }
    }


    
}
