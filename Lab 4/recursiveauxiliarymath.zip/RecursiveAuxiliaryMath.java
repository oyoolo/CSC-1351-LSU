
package recursiveauxiliarymath;

import static java.lang.Double.NaN;

/**
 *
 * @author aoyool1
 */
public class RecursiveAuxiliaryMath {
    /*
    *
    * check if number is palindirome
    */
    public static boolean recursiveIsPalindrome(String num, int i, int j){
        
        if (num.charAt(i)==(num.charAt(j))){
            return true;
        }
        if (num.charAt(i)!= num.charAt(j)){
            return false;
        }
        if (i<j+1){
            return recursiveIsPalindrome(num, i++, j--);
        }

        return true;
    }
    /*
    *
    * calculate fibonacci
    */
    public static long recursiveFibonacci(int n){
        long fibonacci = 1;
        if (n <= 0){
        fibonacci = n; 
        }
        else {

         fibonacci = Math.abs(recursiveFibonacci(n-1)+recursiveFibonacci(n-2));
     }
    return fibonacci; 
 }
    /*
    *
    * calculate gcd
    */
    public static int recursiveGCD(int a, int b){
	int GCD =1;

	if (a==0 && b ==0){			
			//throw new IllegalArgumentException("Cannot find GCD of 0");
		GCD = (int) NaN;
	} 

	else if (a==0|| b ==0){
		GCD = Math.abs(a+b);
	}
	else {
		a = Math.abs(a);
		b = Math.abs(b);

		GCD = recursiveGCD(b, a%b);
	}        

	return GCD;

    }
    /*
    *
    * calculate power
    */
    public static double recursivePowInt(double b, int n){
        double power =0;
     
    //Show Exception On Screen if b ==0
        if (b== 0 && n ==0){
         throw new ArithmeticException ("Base and Power cannot be a 0");
        }
     
        if (b==0 && n <=0)
        {
            power = (int) NaN;
        } 
    
        else if (b == 0 && n >0) {
            power = 0;
        }
    
        else if (b ==1) {
            power = 1;
        }
    
        else if (b == -1 && n%2 ==0){
            power =1;
        }
    
        else if (b == -1 && n%2 !=0){
            power = -1;
        }
        else if (n == 0 ){
            power = 1;
        }
    
        else if (n == 1){
            power = b;
        }
    
        else if (n == -1){
            power = 1/b;
        }
    
        else if(n>0){

            power = (b*recursivePowInt(b,n-1));
        }
    
        else if (n <0){
            n = Math.abs(n);
           
            power = 1/(b*recursivePowInt(b,n-1));
            
        }
        return power;
     
    }
}
