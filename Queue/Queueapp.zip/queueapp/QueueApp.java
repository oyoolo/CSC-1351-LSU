package queueapp;

/**
 * Test our array-list-based queue ADT implementation
 *
 */
public class QueueApp {

    public static void main(String[] args) throws Exception {
        Queue<Integer> nums = new Queue<>();
        nums.enqueue(12);
        System.out.printf("%d inserted in the queue.%n", 12);
        nums.enqueue(4);
        System.out.printf("%d inserted in the queue.%n", 4);
        nums.enqueue(51);
        System.out.printf("%d inserted in the queue.%n", 51);
        nums.enqueue(1);
        System.out.printf("%d inserted in the queue.%n", 1);
        nums.enqueue(16);
        System.out.printf("%d inserted in the queue.%n", 16);
        nums.enqueue(5);
        System.out.printf("%d inserted in the queue.%n%n", 5);
        System.out.println(nums);
        nums.leftRotate();
        System.out.println(nums);
        nums.rightRotate();
        System.out.println(nums);
        if (!nums.isEmpty()) {
            System.out.printf("%d is at the front of the queue.%n", nums.front());
            System.out.printf("The queue is not empty%n%n");
        } else {
            System.out.println("The queue is empty.%n%n");
        }
        while (!nums.isEmpty()) {
            System.out.printf("%d is at the front of the queue.%n", nums.front());
            System.out.printf("%d has been removed from the front.%n", nums.dequeue());
        }
    }
}
