/**
 * An array-list-based implementation of a queue.
 * CSC 1351 Lab # 6
 *
 * @author Aubrey Oyoolo
 * @since 11/5/2015
 */
package queueapp;

import java.util.*;

public class Queue<E> implements QueueAPI<E> {

    /**
     * stores the elements of the queue such that the first element of the array
     * list is at the head of the queue and its last element is at the back of
     * the queue.
     */
    private ArrayList<E> list;

    /**
     * constructs an empty queue.
     */
    public Queue() {
        list = new ArrayList();
    }

    @Override
    public boolean isEmpty() {
        return (size() == 0);
    }

    @Override
    public void enqueue(E obj) {
        list.add(obj);
    }

    @Override
    public E front() throws Exception {
        if (size() == 0) {
            throw new Exception("Non-empty queue expected");
        }
        return list.get(0);
    }

    @Override
    public E dequeue() throws Exception {
        if (isEmpty()) {
            throw new Exception("Non-empty queue expected");
        }
        E tmp = list.get(0);
        list.remove(0);
        return tmp;
    }

    @Override
    public long size() {
        return list.size();
    }

    /**
     * Moves the element from the back of this queue, its right-most elements,
     * and puts it at the head of the queue so that it becomes the left-most
     * element. it does nothing if the queue is empty.
     *
     * @throws Exception when the queue is empty
     */
    public void leftRotate() throws Exception {
        if (size() == 0) {
            throw new Exception("Cannot rotate an empty queue.");
        }
        E tmp = list.get(list.size() - 1);
        list.remove(list.size() - 1);
        list.add(0, tmp);

    }

    /**
     * Moves the element from the head of this queue, its left-most elements,
     * and puts it at the back of the queue so that it becomes the right-most
     * element; this method does nothing if the queue is empty.
     *
     * @throws Exception when the queue is empty
     */
    public void rightRotate() throws Exception {
        if (size() == 0) {
            throw new Exception("Cannot rotate an empty queue.");
        }
        E tmp;
        tmp = front();
        dequeue();
        enqueue(tmp);
    }

    @Override
    public String toString() {
        return list.toString();
    }
}
