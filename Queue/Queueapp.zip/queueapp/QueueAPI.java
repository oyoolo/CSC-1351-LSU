/**
 * A parameterized interface that defines operations that a queue must implement.
 * CSC 1351 Lab # 6
 *
 * @author Aubrey Oyoolo
 * @since 11/5/2015
 */
package queueapp;

public interface QueueAPI<E> {

    /**
     * Determines whether the queue is empty.
     *
     * @return true if the queue is empty; otherwise, false
     */
    boolean isEmpty();

    /**
     * Inserts an item at the back of the queue.
     *
     * @param item the value to be inserted.
     */
    void enqueue(E item);

    /**
     * Accesses the item at the front of a non-empty queue
     *
     * @return item at the front of the queue.
     * @throws QueueException when this queue is empty
     */
    E front() throws Exception;

    /**
     * Deletes an item from the front of the queue.
     *
     * @return item at the front of the queue.
     * @throws QueueException when this queue is empty
     */
    E dequeue() throws Exception;

    /**
     * Gives the size of the queue.
     *
     * @return the size of the queue
     */
    long size();

}
