import java.util.Scanner;

public class DateDemo {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter the first day of class ->");
		String line = scan.nextLine();
		System.out.println();
		String[] nums = line.split("/");
		int m1 = Integer.parseInt(nums[0]);
		int d1 = Integer.parseInt(nums[1]);
		int y1 = Integer.parseInt(nums[2]);



		Date startDate = new Date (m1, d1, y1);
		startDate.setDate(m1, d1, y1);

		Date lastDate = new Date(startDate);
		lastDate.setDate(m1, d1, y1);




		String[] month = {	
				"January", "February", "March", "April", "May", "June", 
				"July", "August", "September", "October", "November", 
				"December"

		};		


		System.out.println("First day of class: " + findWeekDay(startDate.getMonth(), startDate.getDay(), startDate.getYear()) + ", " + month[startDate.getMonth()-1] + " " + startDate.getDay() + ", "  + startDate.getYear());
		System.out.println("Last day of class: " + findWeekDay(lastDate.getMonth(), lastDate.getDay(), lastDate.getYear()) + ", " + month[lastDate.getMonth()-1] + " " + lastDate.getDay() + ", "  + lastDate.getYear());
		System.out.println();

		System.out.print("Enter the last day of class ->");
		line = scan.nextLine();
		System.out.println();
		nums = line.split("/");
		m1 = Integer.parseInt(nums[0]);
		d1 = Integer.parseInt(nums[1]);
		y1 = Integer.parseInt(nums[2]);

		lastDate.setDate(m1, d1, y1);

		System.out.println("First day of class: " + findWeekDay(startDate.getMonth(), startDate.getDay(), startDate.getYear()) + ", " + month[startDate.getMonth()-1] + " " + startDate.getDay() + ", "  + startDate.getYear());
		System.out.println("Last day of class: " + findWeekDay(lastDate.getMonth(), lastDate.getDay(), lastDate.getYear()) + ", " + month[lastDate.getMonth()-1] + " " + lastDate.getDay() + ", "  + lastDate.getYear());
		System.out.println();
	}


	public static String findWeekDay(int month, int day, int year) {
		int century = year/100;
		int u = 2*(3-(century%4));
		int v = year-(century*100);
		int w =v/4;
		int[] x = {
				0,3,3,6,1,4,6,2,5,0,3,5
		};	

		String[] weekDays = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};
		boolean isLeap = false;

		//Determine leap year
		if(year % 4 == 0)
		{
			if( year % 100 == 0)
			{
				if ( year % 400 == 0)
					isLeap = true;

				else
					isLeap = false;
			}
			else
				isLeap = true;
		}
		else {
			isLeap = false;
		}

		if (isLeap==true) {
			x[0] = 6;
			x[1] = 2;
		} 

		int y = u+v+w+x[month-1]+day;

		int weekDay = (y%7) -1;

		String foundDay = weekDays[weekDay];
		return foundDay;

	}

}
