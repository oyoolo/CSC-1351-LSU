
package auxiliarymath;

import static auxiliarymath.AuxiliaryMath.fibonacci;
import static auxiliarymath.AuxiliaryMath.GCD;
import static auxiliarymath.AuxiliaryMath.powInt;
import static auxiliarymath.AuxiliaryMath.isPalindrome;
import java.util.Scanner;

/**
 *
 * @author aoyool1
 */
public class AuxiliaryMathDemo {

    /**
     * @param args the command line arguments
     * 
     * 
     */
    
    
    public static void main(String[] args) {
    int num1; 
    int num2; 
    int num3;
    
        //Read user input
        Scanner read = new Scanner(System.in); 
        
        
        System.out.println("Enter Three integer whose GCD is to be found -> ");
         num1 = read.nextInt();
         num2 = read.nextInt();
         num3 = read.nextInt();
         
       //Calls the GCD Method
        int GCD = GCD(GCD(num1, num2), num3);

        System.out.println("Enter an integer n to find fibonacci(n) -> ");    
        int n  =read.nextInt();  
        int fib = fibonacci(n);
       
        System.out.println("Enter a base != 0 (double) and an exponent !=0 (integer) -> ");
        double base = read.nextDouble();
        int exponent = read.nextInt();
        double power = powInt(base,exponent);
        
        System.out.println("Enter two positive integers i and j where i < j -> "); 
        int i = read.nextInt();
        int j = read.nextInt();
        
        int counter =0;
        
        //Get number of palindromes between i and j
        for(int w =i; w<j ;w++){
            
            if (isPalindrome(w)){
                counter++;
            } 
        }

        System.out.printf("\n");
     
         
        System.out.println("gcd(" + num1 + ", " + num2 + ", " + num3 + ") = " + GCD);
        System.out.println("fibonacci(" + n + ") = " + fib);
        System.out.println(base + " ^ " + exponent + " = " + power);
        System.out.println("There is "  + counter +  " palindromic numbers between "+ i +" and " + j);
    }


     
}
