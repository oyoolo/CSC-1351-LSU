package auxiliarymath;

import static java.lang.Double.NaN;

/**
 *
 * @author aoyool1
 */
public class AuxiliaryMath {
    
    //returns true if the number is a palindrome
 public static boolean isPalindrome(int n){
     
    
     String num = "" + n;
     int numDigits = num.length();

     
     for (int i = 0; i<numDigits; i++){
         if (num.charAt(i) != num.charAt(numDigits -(i+1)) ){             
                     return false;
         }
         
     }
     
     return true;
   
     
 }
 
 //Compute the fibonacci
 public static int fibonacci(int n){
     int fibonacci = 0;
     if (n <= 0){
        fibonacci = n; 
     }
     else {
//         int prevNum1 = n-1;
//         int prevNum2 = n-2;
         fibonacci = Math.abs(fibonacci(n-1)+fibonacci(n-2));
     }
    return fibonacci; 
 }
 
 //Calculate the GCD
 public static int GCD(int a, int b){
     
     int GCD = 0;
     
     if (a==0&& b ==0){
         GCD = (int) NaN;
     } 
     
     else if (a==0|| b ==0){
         GCD = Math.abs(a+b);
     }
     else {
         a = Math.abs(a);
         b = Math.abs(b);
         
         while (b!=0){
             int r = a%b;
             a= b;
             b= r;
         }
         
         GCD = a;
     }        
             
             
     return GCD;
     
 }
 
 //compute the exponent
 public static double powInt(double b, int n){
     double power =0;
     
    //Show Exception On Screen if b ==0
     if (b== 0 && n ==0){
         throw new ArithmeticException ("Base and Power cannot be a 0");
     }
     
    if (b==0 && n <=0)
    {
        power = (int) NaN;
    } 
    
    else if (b == 0 && n >0) {
        power = 0;
    }
    
    else if (b ==1) {
        power = 1;
    }
    
    else if (b == -1 && n%2 ==0){
        power =1;
    }
    
    else if (b == -1 && n%2 !=0){
        power = -1;
    }
    else if (n == 0 ){
        power = 1;
    }
    
    else if (n == 1){
        power = b;
    }
    
    else if (n == -1){
        power = 1/b;
    }
    
    else if(n>0){
        
            for (int i = 1; i < n; i++) {
                power = b * b;
            }
    }
    
    else if (n <0){
        int num = Math.abs(n);
            for (num = 1; num < n; num++) {
                power = 1/(b * b);
            }
    }
     return power;
     
 }
  
}
